﻿using program_decorations.View.Optional;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace program_decorations.View
{
    public partial class ProductListForm : Form
    {
        private static string ProjDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName;
        DataTable dt;
        List<Order> orders;
        public ProductListForm()
        {
            InitializeComponent();

            cbFilter.SelectedIndex = 0;

            btnCheckOrder.Visible = false;
            btnOrders.Visible = false;
            btnProductAdd.Visible = false;

            contextMenuStrip1.Items[1].Visible = false;

            if (UserData.RoleID == 2)
            {
                btnOrders.Visible = true;
            }

            if (UserData.RoleID == 3)
            {
                bdProdName.ReadOnly = false;
                bdProduDescription.ReadOnly = false;
                bdProduManufacturer.ReadOnly = false;
                bdProductCost.ReadOnly = false;

                mtbDiscount.ReadOnly = false;

                dgvMain.ReadOnly = false;

                btnOrders.Visible = true;
                btnProductAdd.Visible = true;

                contextMenuStrip1.Items[1].Visible = true;
            }
            else { mtbDiscount.ReadOnly = true; }

            if (UserData.RoleID == 4)
            {
                lblName.Text = "";
            }
            else
            {
                lblName.Text = $"{UserData.Surname} {UserData.Name} {UserData.Patronymic}";
            }
        }

        private void FillProdTable()
        {
            try
            {
                if (cbFilter.SelectedIndex == 0)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else if (cbFilter.SelectedIndex == 1)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductDiscountAmount BETWEEN 0 and 9";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else if (cbFilter.SelectedIndex == 2)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductDiscountAmount BETWEEN 10 and 14";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else if (cbFilter.SelectedIndex == 3)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductDiscountAmount >= 15";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products ";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }

                PaintTable();

                // вывод кол-ва товаров
                int getAllProducts = 0;
                int countProducts = dgvMain.RowCount - 1;
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                {
                    connection.Open();

                    string query = "SELECT COUNT(*) FROM Products";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        getAllProducts = (int)command.ExecuteScalar();
                    }
                }
                ProgramCountProducts.Text = $"Товаров '{countProducts}/{getAllProducts}'";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить товары.");
                Console.WriteLine($"Error: {ex}");
            }
        }

        private void PaintTable()
        {
            foreach (DataGridViewRow row in dgvMain.Rows)
            {
                if (Convert.ToInt32(row.Cells[7].Value) > 15)
                {
                    row.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#20b2aa");
                }
            }

            foreach (DataGridViewColumn col in dgvMain.Columns)
            {
                col.ReadOnly = true;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm logInForm = new LogInForm();
            logInForm.Show();
        }

        private void dgvMain_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                bdProdName.Text = dgvMain.CurrentRow.Cells[1].Value.ToString();
                bdProduDescription.Text = dgvMain.CurrentRow.Cells[2].Value.ToString();
                bdProduManufacturer.Text = dgvMain.CurrentRow.Cells[3].Value.ToString();
                bdProductCost.Text = dgvMain.CurrentRow.Cells[6].Value.ToString();

                mtbDiscount.Text = dgvMain.CurrentRow.Cells[7].Value.ToString();

                string productPhoto = dgvMain.CurrentRow.Cells[0].Value.ToString();
                string photoPath = Path.Combine(ProjDirectory, $"Resources\\ProductPhoto\\{productPhoto}.jpg");

                if (File.Exists(photoPath))
                {
                    pbProductPhoto.ImageLocation = Path.Combine(ProjDirectory, $"Resources\\ProductPhoto\\{productPhoto}.jpg");
                }
                else
                {
                    try
                    {
                        pbProductPhoto.ImageLocation = Path.Combine(ProjDirectory, $"Resources\\picture.png");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Не удалось загрузить фотографию");
                        Console.WriteLine($"Error: {ex}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выборе товара в таблице.");
                Console.WriteLine($"Error: {ex}");
            }
        }

        private void rbAscending_CheckedChanged(object sender, EventArgs e)
        {
            dgvMain.Sort(dgvMain.Columns["Цена без скидки"], ListSortDirection.Ascending);
            PaintTable();
        }

        private void rbDescending_CheckedChanged(object sender, EventArgs e)
        {
            dgvMain.Sort(dgvMain.Columns["Цена без скидки"], ListSortDirection.Descending);
            PaintTable();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbSearch.Text))
            {
                try
                {
                    FillProdTable();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось получить товары из базы данных.");
                    Console.WriteLine(ex.Message);
                }
                return;
            }

            try
            {
                if (cbFilter.SelectedIndex == 0)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductName LIKE '%" + tbSearch.Text + "%'";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else if (cbFilter.SelectedIndex == 1)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductName LIKE '%" + tbSearch.Text + "%' and ProductDiscountAmount BETWEEN 0 and 9";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else if (cbFilter.SelectedIndex == 2)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductName LIKE '%" + tbSearch.Text + "%' and ProductDiscountAmount BETWEEN 10 and 14";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }
                else if (cbFilter.SelectedIndex == 3)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string select =
                            "SELECT " +
                                "ProductArticleNumber as Артикул, " +
                                "ProductName as Название, " +
                                "ProductDescription as [Описание товара], " +
                                "ProductManufacturer as Производитель, " +
                                "ProductCategory as Категория, " +
                                "ProductCost as [Цена без скидки] , " +
                                "ProductCost - ((ProductCost / 100) * ProductDiscountAmount) as [Цена со скидкой], " +
                                "ProductDiscountAmount as Скидка, " +
                                "ProductQuantityInStock as Количество " +
                            "FROM " +
                                "Products " +
                                "WHERE ProductName LIKE '%" + tbSearch.Text + "%' and ProductDiscountAmount >= 15";

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = select;
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                        dt = new DataTable("Products");
                        adapter.Fill(dt);
                        dgvMain.DataSource = dt;

                        dgvMain.RowHeadersVisible = false;

                        connection.Close();
                    }
                }

                int GetAllProducts = 0;
                int CountProducts = dgvMain.RowCount - 1;
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                {
                    connection.Open();

                    string query = "SELECT COUNT(*) FROM Products";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        GetAllProducts = (int)command.ExecuteScalar();
                    }
                }
                ProgramCountProducts.Text = $"Товаров '{CountProducts}/{GetAllProducts}'";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось получить товары из базы данных.");
                Console.WriteLine(ex.Message);
            }
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            rbAscending.Checked = false;
            rbDescending.Checked = false;

            FillProdTable();
        }

        private void dgvMain_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int currentRow = e.RowIndex;
                int currentColumn = e.ColumnIndex;

                if (currentRow >= 0)
                {
                    dgvMain.Rows[currentRow].Selected = true;

                    Point point = dgvMain.PointToClient(Cursor.Position);

                    contextMenuStrip1.Show(dgvMain, point);
                }
            }
        }

        private void добавитьКЗаказуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnCheckOrder.Visible = true;

            string ProdArtNum = dgvMain.CurrentRow.Cells[0].Value.ToString();
            string ProdName = dgvMain.CurrentRow.Cells[1].Value.ToString();
            string ProdDescript = dgvMain.CurrentRow.Cells[2].Value.ToString();
            string ProdManufacturer = dgvMain.CurrentRow.Cells[3].Value.ToString();
            string ProdCategory = dgvMain.CurrentRow.Cells[4].Value.ToString();
            string ProdCostWithoutDiscount = dgvMain.CurrentRow.Cells[5].Value.ToString();
            string ProdCostWithDiscount = dgvMain.CurrentRow.Cells[6].Value.ToString();
            string ProdDiscountAmount = dgvMain.CurrentRow.Cells[7].Value.ToString();

            string ProdPhoto = dgvMain.CurrentRow.Cells[0].Value.ToString();
            string PhotoPath = Path.Combine(ProjDirectory, $"Resources\\ProductPhoto\\{ProdPhoto}.jpg");

            if (!File.Exists(PhotoPath))
            {
                PhotoPath = Path.Combine(ProjDirectory, $"Resources\\picture.png");
            }

            Order order = new Order
            {
                photoPath = PhotoPath,
                ProductArticleNumber = ProdArtNum,
                ProductName = ProdName,
                ProductDescription = ProdDescript,
                ProductManufacturer = ProdManufacturer,
                ProductCategory = ProdCategory,
                ProductCostWithoutDiscount = ProdCostWithoutDiscount,
                ProductCostWithDiscount = ProdCostWithDiscount,
                ProductDiscountAmount = ProdDiscountAmount
            };

            if (orders == null)
            {
                orders = new List<Order>();
            }

            orders.Add(order);

            contextMenuStrip1.Hide();
        }

        private void btnCheckOrder_Click(object sender, EventArgs e)
        {
            CartForm cartForm = new CartForm(orders);
            cartForm.ShowDialog();

            if (orders.Count == 0)
            {
                btnCheckOrder.Visible = false;
            }
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrdersForm ordersForm = new OrdersForm();
            ordersForm.Show();
        }

        private void tbProductName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    string ProductArticle = dgvMain.CurrentRow.Cells[0].Value.ToString();

                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string query = "UPDATE Products SET [ProductName ]= @ProductName, ProductDescription = @ProductDescription, ProductManufacturer = @ProductManufacturer, ProductCost = @ProductCost, [ProductDiscountAmount ] = @Discount WHERE ProductArticleNumber = @ProductArticle";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ProductName", bdProdName.Text);
                            command.Parameters.AddWithValue("@ProductDescription", bdProduDescription.Text);
                            command.Parameters.AddWithValue("@ProductManufacturer", bdProduManufacturer.Text);
                            command.Parameters.AddWithValue("@ProductCost", Convert.ToSingle(bdProductCost.Text));
                            command.Parameters.AddWithValue("@Discount", Convert.ToInt32(mtbDiscount.Text));
                            command.Parameters.AddWithValue("@ProductArticle", ProductArticle);

                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Информация о товаре успешно изменена.", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FillProdTable();
                    PaintTable();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось обновить информацию товара.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void btnProductAdd_Click(object sender, EventArgs e)
        {
            ProductAddForm ProdAddForm = new ProductAddForm();
            ProdAddForm.ShowDialog();
            FillProdTable();
            PaintTable();
        }

        private void удалитьТоварToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string productArticle = dgvMain.CurrentRow.Cells[0].Value.ToString();

                DialogResult dialogResult = MessageBox.Show("Вы точно хотите удалить товар?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string query = "DELETE FROM Products WHERE ProductArticleNumber = @ProductArticleNumber";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ProductArticleNumber", productArticle);
                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Товар успешно удален из списка продуктов.", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FillProdTable();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось удалить товар.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Console.WriteLine(ex.Message);
            }
        }

        private void ProdListForm_Load(object sender, EventArgs e)
        {
            FillProdTable();
            PaintTable();
        }

        private void ProdListForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }
    }
}
