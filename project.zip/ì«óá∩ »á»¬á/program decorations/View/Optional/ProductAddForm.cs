﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace program_decorations.View.Optional
{
    public partial class ProductAddForm : Form
    {
        string PhotosPath;
        string PhotoName;
        public ProductAddForm()
        {
            InitializeComponent();
        }

        private bool HasArticle(string article)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                {
                    connection.Open();

                    string query = "SELECT ProductArticleNumber FROM Products WHERE ProductArticleNumber = @ProductArticleNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductArticleNumber", article);

                        var result = command.ExecuteScalar();

                        if (result == null || result == DBNull.Value)
                        {
                            return false;
                        }
                        else
                        {
                            MessageBox.Show("Товар с таким артикулом уже существует в базе данных.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось проверить наличие артикула в базе данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        private void btnProductAdd_Click(object sender, EventArgs e)
        {
            if (!HasArticle(BDProductArticle.Text.Trim()))
            {
                try
                {
                    string ProdArticleNumber = BDProductArticle.Text.Trim();
                    string ProdName = BDProductName.Text.Trim();
                    string ProdUnitOfMeasurement = BDProductUnitOfMesurement.Text.Trim();
                    string ProdDescription = BDProductDescription.Text.Trim();
                    string ProdCategory = BDProductCategory.Text.Trim();
                    string ProdPhoto = PhotoName;
                    string ProdManufacturer = BDProductManufacturer.Text.Trim();
                    string ProdSupp = BDProductSupplier.Text.Trim();

                    double ProdCost;
                    int ProdDiscountAmount;
                    int MaxProdDiscountAmount;
                    int QuantityProdStock;

                    if (!double.TryParse(BDProdCost.Text, out ProdCost))
                    {
                        MessageBox.Show("Не удалось корректно получить цену товара.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(mtbProductDiscountAmount.Text, out ProdDiscountAmount))
                    {
                        MessageBox.Show("Не удалось корректно получить скидку товара.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(mtbProductMaxDiscountAmount.Text, out MaxProdDiscountAmount))
                    {
                        MessageBox.Show("Не удалось корректно получить максимальную скидку товара.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(mtbProductQuantityInStock.Text, out QuantityProdStock))
                    {
                        MessageBox.Show("Не удалось корректно получить количество товара на складе.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionString1))
                    {
                        connection.Open();

                        string query = @"
                        INSERT INTO Products(ProductArticleNumber, [ProductName ], ProductUnitOfMeasurement, ProductDescription, ProductCategory, ProductPhoto, ProdManufacturer, ProductSupplier, ProdCost, [ProdDiscountAmount ], ProductMaxDiscountAmount, ProductQuantityInStock)
                        VALUES (@ProductArticleNumber, @ProductName, @ProductUnitOfMeasurement, @ProductDescription, @ProductCategory, @ProductPhoto, @ProdManufacturer, @ProductSupplier, @ProdCost, @ProdDiscountAmount, @ProductMaxDiscountAmount, @ProductQuantityInStock)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ProductArticleNumber", ProdArticleNumber);
                            command.Parameters.AddWithValue("@ProductName", ProdName);
                            command.Parameters.AddWithValue("@ProductUnitOfMeasurement", ProdUnitOfMeasurement);
                            command.Parameters.AddWithValue("@ProductDescription", ProdDescription);
                            command.Parameters.AddWithValue("@ProductCategory", ProdCategory);

                            if (string.IsNullOrWhiteSpace(PhotoName))
                            {
                                command.Parameters.AddWithValue("@ProductPhoto", DBNull.Value);
                            }
                            else
                            {
                                command.Parameters.AddWithValue("@ProductPhoto", ProdPhoto);
                            }

                            command.Parameters.AddWithValue("@ProdManufacturer", ProdManufacturer);
                            command.Parameters.AddWithValue("@ProductSupplier", ProdSupp);
                            command.Parameters.AddWithValue("@ProdCost", ProdCost);
                            command.Parameters.AddWithValue("@ProdDiscountAmount", ProdDiscountAmount);
                            command.Parameters.AddWithValue("@ProductMaxDiscountAmount", MaxProdDiscountAmount);
                            command.Parameters.AddWithValue("@ProductQuantityInStock", QuantityProdStock);

                            command.ExecuteNonQuery();
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(PhotoName))
                    {
                        string WorkDirectory = Environment.CurrentDirectory;
                        string ProjectDirectory = Directory.GetParent(WorkDirectory).Parent.Parent.FullName;
                        string FolderPhotoesPath = System.IO.Path.Combine(ProjectDirectory, "Resources\\ProductPhoto\\");
                        string DestinationPhotoFile = System.IO.Path.Combine(FolderPhotoesPath, System.IO.Path.GetFileName(PhotoName));

                        File.Copy(PhotoName, DestinationPhotoFile, true);
                    }

                    MessageBox.Show("Товар успешно добавлен.", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось добавить товар.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void btnSelectPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                PhotosPath = openFileDialog.FileName;
                PBDProductPhoto.Image = Image.FromFile(PhotosPath);
                PhotoName = Path.GetFileName(PhotosPath);
            }
        }
    }
}
