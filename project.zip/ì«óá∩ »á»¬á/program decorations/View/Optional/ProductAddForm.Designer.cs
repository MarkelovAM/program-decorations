﻿namespace program_decorations.View.Optional
{
    partial class ProductAddForm
    {
        
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductAddForm));
            this.lblArticle = new System.Windows.Forms.Label();
            this.BDProductArticle = new System.Windows.Forms.TextBox();
            this.BDProductName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.BDProductUnitOfMesurement = new System.Windows.Forms.TextBox();
            this.lblUnitOfMeasure = new System.Windows.Forms.Label();
            this.BDProductDescription = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.BDProductCategory = new System.Windows.Forms.TextBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.PBDProductPhoto = new System.Windows.Forms.PictureBox();
            this.BDProductManufacturer = new System.Windows.Forms.TextBox();
            this.lblManufacturer = new System.Windows.Forms.Label();
            this.BDProductSupplier = new System.Windows.Forms.TextBox();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.BDProdCost = new System.Windows.Forms.TextBox();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblDiscountAmount = new System.Windows.Forms.Label();
            this.lblMaxDiscount = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.mtbProductQuantityInStock = new System.Windows.Forms.MaskedTextBox();
            this.mtbProductMaxDiscountAmount = new System.Windows.Forms.MaskedTextBox();
            this.mtbProductDiscountAmount = new System.Windows.Forms.MaskedTextBox();
            this.pnlOptionalBG = new System.Windows.Forms.Panel();
            this.lblHeading = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.btnSelectPhoto = new System.Windows.Forms.Button();
            this.btnProductAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PBDProductPhoto)).BeginInit();
            this.pnlOptionalBG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblArticle
            // 
            this.lblArticle.AutoSize = true;
            this.lblArticle.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblArticle.Location = new System.Drawing.Point(25, 144);
            this.lblArticle.Name = "lblArticle";
            this.lblArticle.Size = new System.Drawing.Size(78, 24);
            this.lblArticle.TabIndex = 0;
            this.lblArticle.Text = "Артикул";
            // 
            // BDProductArticle
            // 
            this.BDProductArticle.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductArticle.Location = new System.Drawing.Point(220, 138);
            this.BDProductArticle.Name = "BDProductArticle";
            this.BDProductArticle.Size = new System.Drawing.Size(100, 30);
            this.BDProductArticle.TabIndex = 1;
            // 
            // BDProductName
            // 
            this.BDProductName.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductName.Location = new System.Drawing.Point(220, 170);
            this.BDProductName.Name = "BDProductName";
            this.BDProductName.Size = new System.Drawing.Size(100, 30);
            this.BDProductName.TabIndex = 3;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblName.Location = new System.Drawing.Point(25, 176);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(134, 24);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Наименование";
            // 
            // BDProductUnitOfMesurement
            // 
            this.BDProductUnitOfMesurement.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductUnitOfMesurement.Location = new System.Drawing.Point(220, 202);
            this.BDProductUnitOfMesurement.Name = "BDProductUnitOfMesurement";
            this.BDProductUnitOfMesurement.Size = new System.Drawing.Size(100, 30);
            this.BDProductUnitOfMesurement.TabIndex = 5;
            // 
            // lblUnitOfMeasure
            // 
            this.lblUnitOfMeasure.AutoSize = true;
            this.lblUnitOfMeasure.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUnitOfMeasure.Location = new System.Drawing.Point(25, 208);
            this.lblUnitOfMeasure.Name = "lblUnitOfMeasure";
            this.lblUnitOfMeasure.Size = new System.Drawing.Size(176, 24);
            this.lblUnitOfMeasure.TabIndex = 4;
            this.lblUnitOfMeasure.Text = "Еденица имзерения";
            // 
            // BDProductDescription
            // 
            this.BDProductDescription.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductDescription.Location = new System.Drawing.Point(220, 234);
            this.BDProductDescription.Name = "BDProductDescription";
            this.BDProductDescription.Size = new System.Drawing.Size(100, 30);
            this.BDProductDescription.TabIndex = 7;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDescription.Location = new System.Drawing.Point(25, 240);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(95, 24);
            this.lblDescription.TabIndex = 6;
            this.lblDescription.Text = "Описание";
            // 
            // BDProductCategory
            // 
            this.BDProductCategory.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductCategory.Location = new System.Drawing.Point(220, 266);
            this.BDProductCategory.Name = "BDProductCategory";
            this.BDProductCategory.Size = new System.Drawing.Size(100, 30);
            this.BDProductCategory.TabIndex = 9;
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCategory.Location = new System.Drawing.Point(25, 272);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(95, 24);
            this.lblCategory.TabIndex = 8;
            this.lblCategory.Text = "Категория";
            // 
            // PBDProductPhoto
            // 
            this.PBDProductPhoto.Location = new System.Drawing.Point(340, 138);
            this.PBDProductPhoto.Name = "PBDProductPhoto";
            this.PBDProductPhoto.Size = new System.Drawing.Size(189, 170);
            this.PBDProductPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBDProductPhoto.TabIndex = 10;
            this.PBDProductPhoto.TabStop = false;
            // 
            // BDProductManufacturer
            // 
            this.BDProductManufacturer.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductManufacturer.Location = new System.Drawing.Point(220, 298);
            this.BDProductManufacturer.Name = "BDProductManufacturer";
            this.BDProductManufacturer.Size = new System.Drawing.Size(100, 30);
            this.BDProductManufacturer.TabIndex = 13;
            // 
            // lblManufacturer
            // 
            this.lblManufacturer.AutoSize = true;
            this.lblManufacturer.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblManufacturer.Location = new System.Drawing.Point(25, 304);
            this.lblManufacturer.Name = "lblManufacturer";
            this.lblManufacturer.Size = new System.Drawing.Size(139, 24);
            this.lblManufacturer.TabIndex = 12;
            this.lblManufacturer.Text = "Производитель";
            // 
            // BDProductSupplier
            // 
            this.BDProductSupplier.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProductSupplier.Location = new System.Drawing.Point(220, 330);
            this.BDProductSupplier.Name = "BDProductSupplier";
            this.BDProductSupplier.Size = new System.Drawing.Size(100, 30);
            this.BDProductSupplier.TabIndex = 15;
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSupplier.Location = new System.Drawing.Point(25, 336);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(102, 24);
            this.lblSupplier.TabIndex = 14;
            this.lblSupplier.Text = "Поставщик";
            // 
            // BDProdCost
            // 
            this.BDProdCost.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BDProdCost.Location = new System.Drawing.Point(220, 362);
            this.BDProdCost.Name = "BDProdCost";
            this.BDProdCost.Size = new System.Drawing.Size(100, 30);
            this.BDProdCost.TabIndex = 17;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCost.Location = new System.Drawing.Point(25, 368);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(52, 24);
            this.lblCost.TabIndex = 16;
            this.lblCost.Text = "Цена";
            // 
            // lblDiscountAmount
            // 
            this.lblDiscountAmount.AutoSize = true;
            this.lblDiscountAmount.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDiscountAmount.Location = new System.Drawing.Point(25, 400);
            this.lblDiscountAmount.Name = "lblDiscountAmount";
            this.lblDiscountAmount.Size = new System.Drawing.Size(66, 24);
            this.lblDiscountAmount.TabIndex = 18;
            this.lblDiscountAmount.Text = "Скидка";
            // 
            // lblMaxDiscount
            // 
            this.lblMaxDiscount.AutoSize = true;
            this.lblMaxDiscount.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMaxDiscount.Location = new System.Drawing.Point(25, 429);
            this.lblMaxDiscount.Name = "lblMaxDiscount";
            this.lblMaxDiscount.Size = new System.Drawing.Size(190, 24);
            this.lblMaxDiscount.TabIndex = 20;
            this.lblMaxDiscount.Text = "Максимальная скидка";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblQuantity.Location = new System.Drawing.Point(25, 464);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(154, 24);
            this.lblQuantity.TabIndex = 22;
            this.lblQuantity.Text = "Кол-во на складе";
            // 
            // mtbProductQuantityInStock
            // 
            this.mtbProductQuantityInStock.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mtbProductQuantityInStock.Location = new System.Drawing.Point(220, 458);
            this.mtbProductQuantityInStock.Mask = "00000";
            this.mtbProductQuantityInStock.Name = "mtbProductQuantityInStock";
            this.mtbProductQuantityInStock.Size = new System.Drawing.Size(100, 30);
            this.mtbProductQuantityInStock.TabIndex = 24;
            this.mtbProductQuantityInStock.ValidatingType = typeof(int);
            // 
            // mtbProductMaxDiscountAmount
            // 
            this.mtbProductMaxDiscountAmount.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mtbProductMaxDiscountAmount.Location = new System.Drawing.Point(220, 426);
            this.mtbProductMaxDiscountAmount.Mask = "00";
            this.mtbProductMaxDiscountAmount.Name = "mtbProductMaxDiscountAmount";
            this.mtbProductMaxDiscountAmount.Size = new System.Drawing.Size(100, 30);
            this.mtbProductMaxDiscountAmount.TabIndex = 25;
            this.mtbProductMaxDiscountAmount.ValidatingType = typeof(int);
            // 
            // mtbProductDiscountAmount
            // 
            this.mtbProductDiscountAmount.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mtbProductDiscountAmount.Location = new System.Drawing.Point(220, 394);
            this.mtbProductDiscountAmount.Mask = "00";
            this.mtbProductDiscountAmount.Name = "mtbProductDiscountAmount";
            this.mtbProductDiscountAmount.Size = new System.Drawing.Size(100, 30);
            this.mtbProductDiscountAmount.TabIndex = 26;
            this.mtbProductDiscountAmount.ValidatingType = typeof(int);
            // 
            // pnlOptionalBG
            // 
            this.pnlOptionalBG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(153)))));
            this.pnlOptionalBG.Controls.Add(this.lblHeading);
            this.pnlOptionalBG.Controls.Add(this.pbLogo);
            this.pnlOptionalBG.Location = new System.Drawing.Point(-1, -1);
            this.pnlOptionalBG.Name = "pnlOptionalBG";
            this.pnlOptionalBG.Size = new System.Drawing.Size(556, 122);
            this.pnlOptionalBG.TabIndex = 27;
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblHeading.Location = new System.Drawing.Point(207, 41);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(287, 33);
            this.lblHeading.TabIndex = 30;
            this.lblHeading.Text = "ДОБАВЛЕНИЕ ТОВАРА";
            // 
            // pbLogo
            // 
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(12, 11);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(88, 89);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo.TabIndex = 7;
            this.pbLogo.TabStop = false;
            // 
            // btnSelectPhoto
            // 
            this.btnSelectPhoto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.btnSelectPhoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectPhoto.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSelectPhoto.Location = new System.Drawing.Point(337, 316);
            this.btnSelectPhoto.Name = "btnSelectPhoto";
            this.btnSelectPhoto.Size = new System.Drawing.Size(195, 62);
            this.btnSelectPhoto.TabIndex = 28;
            this.btnSelectPhoto.Text = "ВЫБРАТЬ ФОТОГРАФИЮ";
            this.btnSelectPhoto.UseVisualStyleBackColor = false;
            this.btnSelectPhoto.Click += new System.EventHandler(this.btnSelectPhoto_Click);
            // 
            // btnProductAdd
            // 
            this.btnProductAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.btnProductAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductAdd.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnProductAdd.Location = new System.Drawing.Point(337, 394);
            this.btnProductAdd.Name = "btnProductAdd";
            this.btnProductAdd.Size = new System.Drawing.Size(195, 62);
            this.btnProductAdd.TabIndex = 29;
            this.btnProductAdd.Text = "добавить товар";
            this.btnProductAdd.UseVisualStyleBackColor = false;
            this.btnProductAdd.Click += new System.EventHandler(this.btnProductAdd_Click);
            // 
            // ProductAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(553, 559);
            this.Controls.Add(this.btnProductAdd);
            this.Controls.Add(this.btnSelectPhoto);
            this.Controls.Add(this.pnlOptionalBG);
            this.Controls.Add(this.mtbProductDiscountAmount);
            this.Controls.Add(this.mtbProductMaxDiscountAmount);
            this.Controls.Add(this.mtbProductQuantityInStock);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblMaxDiscount);
            this.Controls.Add(this.lblDiscountAmount);
            this.Controls.Add(this.BDProdCost);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.BDProductSupplier);
            this.Controls.Add(this.lblSupplier);
            this.Controls.Add(this.BDProductManufacturer);
            this.Controls.Add(this.lblManufacturer);
            this.Controls.Add(this.PBDProductPhoto);
            this.Controls.Add(this.BDProductCategory);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.BDProductDescription);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.BDProductUnitOfMesurement);
            this.Controls.Add(this.lblUnitOfMeasure);
            this.Controls.Add(this.BDProductName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.BDProductArticle);
            this.Controls.Add(this.lblArticle);
            this.Font = new System.Drawing.Font("Comic Sans MS", 8.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "ProductAddForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавление товара";
            ((System.ComponentModel.ISupportInitialize)(this.PBDProductPhoto)).EndInit();
            this.pnlOptionalBG.ResumeLayout(false);
            this.pnlOptionalBG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblArticle;
        private System.Windows.Forms.TextBox BDProductArticle;
        private System.Windows.Forms.TextBox BDProductName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox BDProductUnitOfMesurement;
        private System.Windows.Forms.Label lblUnitOfMeasure;
        private System.Windows.Forms.TextBox BDProductDescription;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox BDProductCategory;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.PictureBox PBDProductPhoto;
        private System.Windows.Forms.TextBox BDProductManufacturer;
        private System.Windows.Forms.Label lblManufacturer;
        private System.Windows.Forms.TextBox BDProductSupplier;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.TextBox BDProdCost;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblDiscountAmount;
        private System.Windows.Forms.Label lblMaxDiscount;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.MaskedTextBox mtbProductQuantityInStock;
        private System.Windows.Forms.MaskedTextBox mtbProductMaxDiscountAmount;
        private System.Windows.Forms.MaskedTextBox mtbProductDiscountAmount;
        private System.Windows.Forms.Panel pnlOptionalBG;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Button btnSelectPhoto;
        private System.Windows.Forms.Button btnProductAdd;
        private System.Windows.Forms.Label lblHeading;
    }
}