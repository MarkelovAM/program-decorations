﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace program_decorations.View.Optional
{
    public partial class CouponForm : Form
    {
        List<Order> Order;
        DateTime OrderDate;
        int OrderId;
        double SumWithDiscount;
        int sumDiscountAmount;
        string SelPickUpPointName;
        int OrderCode;

        public CouponForm(List<Order> order1, DateTime orderDate1, int orderId1, double sumWithDiscount1, int sumDiscountAmount1, string selectedPickUpPointName1, int orderCode1)
        {
            Order = order1;
            OrderDate = orderDate1;
            OrderId = orderId1;
            SumWithDiscount = sumWithDiscount1;
            sumDiscountAmount = sumDiscountAmount1;
            SelPickUpPointName = selectedPickUpPointName1;
            OrderCode = orderCode1;

            InitializeComponent();
            FillListBox();
        }

        private void FillListBox()
        {
            try
            {
                lbOrders.DisplayMember = "ProductNameInListBox";

                lbOrders.DataSource = Order;

                FillLabels();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось заполнить корзину товаров", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Console.WriteLine(ex.Message);
            }
        }

        private void FillLabels()
        {
            lblOrderDate.Text = "Дата заказа: " + OrderDate.ToString();
            lblOrderNumber.Text = "Номер заказа: " + OrderId.ToString();
            lblSumWithDiscount.Text = "Сумма заказа: " + SumWithDiscount.ToString();
            lblDiscountAmount.Text = "Сумма скидки: " + sumDiscountAmount.ToString();
            lblPickUpPoint.Text = "Пункт выдачи: " + SelPickUpPointName;
            lblOrderCode.Text = "Код для получения: " + OrderCode.ToString();
        }

        private void lblOrderDate_Click(object sender, EventArgs e)
        {

        }
    }
}
